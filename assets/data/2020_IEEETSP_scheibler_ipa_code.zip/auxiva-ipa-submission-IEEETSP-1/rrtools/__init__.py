from .dumbparallel import run
from .tools import get_git_hash, DirtyGitRepositoryError, \
        InvalidGitRepositoryError, json_append
