import numpy as np


def tensor_H(X):
    return np.conj(X).swapaxes(-1, -2)


def crandn(*shape):
    return np.random.randn(*shape) + 1j * np.random.randn(*shape)


def rand_psd(*shape, dtype=np.complex):
    shape = list(shape) + [shape[-1]]
    X = crandn(*shape)
    return X @ tensor_H(X) / shape[-1]
